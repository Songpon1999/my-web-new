# app/controllers/tasks_controller.rb
class TasksController < ApplicationController
  def index
    @categories = Category.includes(:tasks)
  end
end
